<?php

class JMSSerializerAdapter_a5dd94b extends \FOS\RestBundle\Serializer\JMSSerializerAdapter implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $valueHolder2ba47 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer6ecb6 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties7e9ea = [
        
    ];

    public function serialize($data, $format, \FOS\RestBundle\Context\Context $context)
    {
        $this->initializer6ecb6 && ($this->initializer6ecb6->__invoke($valueHolder2ba47, $this, 'serialize', array('data' => $data, 'format' => $format, 'context' => $context), $this->initializer6ecb6) || 1) && $this->valueHolder2ba47 = $valueHolder2ba47;

        return $this->valueHolder2ba47->serialize($data, $format, $context);
    }

    public function deserialize($data, $type, $format, \FOS\RestBundle\Context\Context $context)
    {
        $this->initializer6ecb6 && ($this->initializer6ecb6->__invoke($valueHolder2ba47, $this, 'deserialize', array('data' => $data, 'type' => $type, 'format' => $format, 'context' => $context), $this->initializer6ecb6) || 1) && $this->valueHolder2ba47 = $valueHolder2ba47;

        return $this->valueHolder2ba47->deserialize($data, $type, $format, $context);
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? $reflection = new \ReflectionClass(__CLASS__);
        $instance = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\FOS\RestBundle\Serializer\JMSSerializerAdapter $instance) {
            unset($instance->serializer, $instance->serializationContextFactory, $instance->deserializationContextFactory);
        }, $instance, 'FOS\\RestBundle\\Serializer\\JMSSerializerAdapter')->__invoke($instance);

        $instance->initializer6ecb6 = $initializer;

        return $instance;
    }

    public function __construct(\JMS\Serializer\SerializerInterface $serializer, ?\JMS\Serializer\ContextFactory\SerializationContextFactoryInterface $serializationContextFactory = null, ?\JMS\Serializer\ContextFactory\DeserializationContextFactoryInterface $deserializationContextFactory = null)
    {
        static $reflection;

        if (! $this->valueHolder2ba47) {
            $reflection = $reflection ?: new \ReflectionClass('FOS\\RestBundle\\Serializer\\JMSSerializerAdapter');
            $this->valueHolder2ba47 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\FOS\RestBundle\Serializer\JMSSerializerAdapter $instance) {
            unset($instance->serializer, $instance->serializationContextFactory, $instance->deserializationContextFactory);
        }, $this, 'FOS\\RestBundle\\Serializer\\JMSSerializerAdapter')->__invoke($this);

        }

        $this->valueHolder2ba47->__construct($serializer, $serializationContextFactory, $deserializationContextFactory);
    }

    public function & __get($name)
    {
        $this->initializer6ecb6 && ($this->initializer6ecb6->__invoke($valueHolder2ba47, $this, '__get', ['name' => $name], $this->initializer6ecb6) || 1) && $this->valueHolder2ba47 = $valueHolder2ba47;

        if (isset(self::$publicProperties7e9ea[$name])) {
            return $this->valueHolder2ba47->$name;
        }

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2ba47;

            $backtrace = debug_backtrace(false);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    get_parent_class($this),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
            return;
        }

        $targetObject = $this->valueHolder2ba47;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer6ecb6 && ($this->initializer6ecb6->__invoke($valueHolder2ba47, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer6ecb6) || 1) && $this->valueHolder2ba47 = $valueHolder2ba47;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2ba47;

            return $targetObject->$name = $value;
            return;
        }

        $targetObject = $this->valueHolder2ba47;
        $accessor = function & () use ($targetObject, $name, $value) {
            return $targetObject->$name = $value;
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer6ecb6 && ($this->initializer6ecb6->__invoke($valueHolder2ba47, $this, '__isset', array('name' => $name), $this->initializer6ecb6) || 1) && $this->valueHolder2ba47 = $valueHolder2ba47;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2ba47;

            return isset($targetObject->$name);
            return;
        }

        $targetObject = $this->valueHolder2ba47;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer6ecb6 && ($this->initializer6ecb6->__invoke($valueHolder2ba47, $this, '__unset', array('name' => $name), $this->initializer6ecb6) || 1) && $this->valueHolder2ba47 = $valueHolder2ba47;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2ba47;

            unset($targetObject->$name);
            return;
        }

        $targetObject = $this->valueHolder2ba47;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __clone()
    {
        $this->initializer6ecb6 && ($this->initializer6ecb6->__invoke($valueHolder2ba47, $this, '__clone', array(), $this->initializer6ecb6) || 1) && $this->valueHolder2ba47 = $valueHolder2ba47;

        $this->valueHolder2ba47 = clone $this->valueHolder2ba47;
    }

    public function __sleep()
    {
        $this->initializer6ecb6 && ($this->initializer6ecb6->__invoke($valueHolder2ba47, $this, '__sleep', array(), $this->initializer6ecb6) || 1) && $this->valueHolder2ba47 = $valueHolder2ba47;

        return array('valueHolder2ba47');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\FOS\RestBundle\Serializer\JMSSerializerAdapter $instance) {
            unset($instance->serializer, $instance->serializationContextFactory, $instance->deserializationContextFactory);
        }, $this, 'FOS\\RestBundle\\Serializer\\JMSSerializerAdapter')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null)
    {
        $this->initializer6ecb6 = $initializer;
    }

    public function getProxyInitializer()
    {
        return $this->initializer6ecb6;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer6ecb6 && ($this->initializer6ecb6->__invoke($valueHolder2ba47, $this, 'initializeProxy', array(), $this->initializer6ecb6) || 1) && $this->valueHolder2ba47 = $valueHolder2ba47;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder2ba47;
    }

    public function getWrappedValueHolderValue() : ?object
    {
        return $this->valueHolder2ba47;
    }


}
