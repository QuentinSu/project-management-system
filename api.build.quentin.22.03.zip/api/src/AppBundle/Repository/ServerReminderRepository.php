<?php

namespace AppBundle\Repository;


class ServerReminderRepository extends \Doctrine\ORM\EntityRepository
{
}
