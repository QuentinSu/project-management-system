<?php

namespace AppBundle\Repository;

class ServerRepository extends \Doctrine\ORM\EntityRepository
{
}
