<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);
        $requestMethod = $canonicalMethod = $context->getMethod();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }

        if (0 === strpos($pathinfo, '/p')) {
            if (0 === strpos($pathinfo, '/project')) {
                // app_checklist_get
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_checklist_get')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController::getAction',));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_checklist_get;
                    }

                    return $ret;
                }
                not_app_checklist_get:

                // app_checklist_post
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_checklist_post')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController::postAction',));
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_app_checklist_post;
                    }

                    return $ret;
                }
                not_app_checklist_post:

                // app_checklist_put
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_checklist_put')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController::putAction',));
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_checklist_put;
                    }

                    return $ret;
                }
                not_app_checklist_put:

                // app_checklist_delete
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_checklist_delete')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController::deleteAction',));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_app_checklist_delete;
                    }

                    return $ret;
                }
                not_app_checklist_delete:

                // app_checklist_postmessage
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)/message$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_checklist_postmessage')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController::postMessageAction',));
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_app_checklist_postmessage;
                    }

                    return $ret;
                }
                not_app_checklist_postmessage:

                // app_checklist_putmessage
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)/message/(?P<message>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_checklist_putmessage')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController::putMessageAction',));
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_checklist_putmessage;
                    }

                    return $ret;
                }
                not_app_checklist_putmessage:

                // app_checklist_deletemessage
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)/message/(?P<message>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_checklist_deletemessage')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController::deleteMessageAction',));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_app_checklist_deletemessage;
                    }

                    return $ret;
                }
                not_app_checklist_deletemessage:

                // app_checklist_postitem
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)/item$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_checklist_postitem')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController::postItemAction',));
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_app_checklist_postitem;
                    }

                    return $ret;
                }
                not_app_checklist_postitem:

                // app_checklist_putitem
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)/item/(?P<item>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_checklist_putitem')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController::putItemAction',));
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_checklist_putitem;
                    }

                    return $ret;
                }
                not_app_checklist_putitem:

                // app_checklist_deleteitem
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)/item/(?P<item>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_checklist_deleteitem')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController::deleteItemAction',));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_app_checklist_deleteitem;
                    }

                    return $ret;
                }
                not_app_checklist_deleteitem:

                // app_project_get
                if ('/project' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ProjectController::getAction',  '_route' => 'app_project_get',);
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_project_get;
                    }

                    return $ret;
                }
                not_app_project_get:

                // app_project_id
                if (preg_match('#^/project/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_project_id')), array (  '_controller' => 'AppBundle\\Controller\\ProjectController::idAction',));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_project_id;
                    }

                    return $ret;
                }
                not_app_project_id:

                // app_project_idactionusers
                if (preg_match('#^/project/(?P<id>[^/]++)/users$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_project_idactionusers')), array (  '_controller' => 'AppBundle\\Controller\\ProjectController::idActionUsers',));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_project_idactionusers;
                    }

                    return $ret;
                }
                not_app_project_idactionusers:

                // app_project_post
                if ('/project' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ProjectController::postAction',  '_route' => 'app_project_post',);
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_app_project_post;
                    }

                    return $ret;
                }
                not_app_project_post:

                // app_project_update
                if (preg_match('#^/project/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_project_update')), array (  '_controller' => 'AppBundle\\Controller\\ProjectController::updateAction',));
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_project_update;
                    }

                    return $ret;
                }
                not_app_project_update:

                // app_project_delete
                if (preg_match('#^/project/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_project_delete')), array (  '_controller' => 'AppBundle\\Controller\\ProjectController::deleteAction',));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_app_project_delete;
                    }

                    return $ret;
                }
                not_app_project_delete:

                // app_project_postnotification
                if (preg_match('#^/project/(?P<project>[^/]++)/notify$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_project_postnotification')), array (  '_controller' => 'AppBundle\\Controller\\ProjectController::postNotificationAction',));
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_app_project_postnotification;
                    }

                    return $ret;
                }
                not_app_project_postnotification:

                // app_project_postfile
                if (preg_match('#^/project/(?P<project>[^/]++)/file$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_project_postfile')), array (  '_controller' => 'AppBundle\\Controller\\ProjectController::postFileAction',));
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_app_project_postfile;
                    }

                    return $ret;
                }
                not_app_project_postfile:

                // app_supportticket_get
                if (preg_match('#^/project/(?P<project>[^/]++)/ticket$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_supportticket_get')), array (  '_controller' => 'AppBundle\\Controller\\SupportTicketController::getAction',));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_supportticket_get;
                    }

                    return $ret;
                }
                not_app_supportticket_get:

                // app_supportticket_post
                if (preg_match('#^/project/(?P<project>[^/]++)/ticket$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_supportticket_post')), array (  '_controller' => 'AppBundle\\Controller\\SupportTicketController::postAction',));
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_app_supportticket_post;
                    }

                    return $ret;
                }
                not_app_supportticket_post:

                // app_supportticket_put
                if (preg_match('#^/project/(?P<project>[^/]++)/ticket/(?P<ticket>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_supportticket_put')), array (  '_controller' => 'AppBundle\\Controller\\SupportTicketController::putAction',));
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_supportticket_put;
                    }

                    return $ret;
                }
                not_app_supportticket_put:

                // app_supportticket_delete
                if (preg_match('#^/project/(?P<project>[^/]++)/ticket/(?P<ticket>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_supportticket_delete')), array (  '_controller' => 'AppBundle\\Controller\\SupportTicketController::deleteAction',));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_app_supportticket_delete;
                    }

                    return $ret;
                }
                not_app_supportticket_delete:

                // app_supportticket_postfile
                if (preg_match('#^/project/(?P<project>[^/]++)/ticket/(?P<ticket>[^/]++)/file$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_supportticket_postfile')), array (  '_controller' => 'AppBundle\\Controller\\SupportTicketController::postFileAction',));
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_app_supportticket_postfile;
                    }

                    return $ret;
                }
                not_app_supportticket_postfile:

                // app_supportticket_deletefile
                if (preg_match('#^/project/(?P<project>[^/]++)/ticket/(?P<ticket>[^/]++)/file/(?P<path>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_supportticket_deletefile')), array (  '_controller' => 'AppBundle\\Controller\\SupportTicketController::deleteFileAction',));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_app_supportticket_deletefile;
                    }

                    return $ret;
                }
                not_app_supportticket_deletefile:

                // app_supportticket_getfile
                if (preg_match('#^/project/(?P<project>[^/]++)/ticket/(?P<ticket>[^/]++)/file/(?P<path>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_supportticket_getfile')), array (  '_controller' => 'AppBundle\\Controller\\SupportTicketController::getFileAction',));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_supportticket_getfile;
                    }

                    return $ret;
                }
                not_app_supportticket_getfile:

                // id_project
                if (preg_match('#^/project/(?P<id>[^/]++)/users(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'id_project')), array (  '_controller' => 'AppBundle\\Controller\\ProjectController:idActionUsers',  '_format' => NULL,));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_id_project;
                    }

                    return $ret;
                }
                not_id_project:

                // post_project_notification
                if (preg_match('#^/project/(?P<project>[^/]++)/notify(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'post_project_notification')), array (  '_controller' => 'AppBundle\\Controller\\ProjectController:postNotificationAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_post_project_notification;
                    }

                    return $ret;
                }
                not_post_project_notification:

                // post_project_message
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)/message(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'post_project_message')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController:postMessageAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_post_project_message;
                    }

                    return $ret;
                }
                not_post_project_message:

                // put_project_message
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)/message/(?P<message>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'put_project_message')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController:putMessageAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_put_project_message;
                    }

                    return $ret;
                }
                not_put_project_message:

                // delete_project_message
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)/message/(?P<message>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_project_message')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController:deleteMessageAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_delete_project_message;
                    }

                    return $ret;
                }
                not_delete_project_message:

                // post_project_item
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)/item(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'post_project_item')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController:postItemAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_post_project_item;
                    }

                    return $ret;
                }
                not_post_project_item:

                // put_project_item
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)/item/(?P<item>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'put_project_item')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController:putItemAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_put_project_item;
                    }

                    return $ret;
                }
                not_put_project_item:

                // delete_project_item
                if (preg_match('#^/project/(?P<project>[^/]++)/checklist/(?P<checklist>[^/]++)/item/(?P<item>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_project_item')), array (  '_controller' => 'AppBundle\\Controller\\ChecklistController:deleteItemAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_delete_project_item;
                    }

                    return $ret;
                }
                not_delete_project_item:

                // put_project
                if (preg_match('#^/project/(?P<project>[^/]++)/ticket/(?P<ticket>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'put_project')), array (  '_controller' => 'AppBundle\\Controller\\SupportTicketController:putAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_put_project;
                    }

                    return $ret;
                }
                not_put_project:

                // post_project_file
                if (preg_match('#^/project/(?P<project>[^/]++)/ticket/(?P<ticket>[^/]++)/file(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'post_project_file')), array (  '_controller' => 'AppBundle\\Controller\\SupportTicketController:postFileAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_post_project_file;
                    }

                    return $ret;
                }
                not_post_project_file:

                // delete_project_file
                if (preg_match('#^/project/(?P<project>[^/]++)/ticket/(?P<ticket>[^/]++)/file/(?P<path>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_project_file')), array (  '_controller' => 'AppBundle\\Controller\\SupportTicketController:deleteFileAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_delete_project_file;
                    }

                    return $ret;
                }
                not_delete_project_file:

                // get_project_file
                if (preg_match('#^/project/(?P<project>[^/]++)/ticket/(?P<ticket>[^/]++)/file/(?P<path>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'get_project_file')), array (  '_controller' => 'AppBundle\\Controller\\SupportTicketController:getFileAction',  '_format' => NULL,));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_get_project_file;
                    }

                    return $ret;
                }
                not_get_project_file:

            }

            elseif (0 === strpos($pathinfo, '/profile')) {
                // app_restprofile_getcurrent
                if ('/profile' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\RestProfileController::getCurrentAction',  '_route' => 'app_restprofile_getcurrent',);
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_restprofile_getcurrent;
                    }

                    return $ret;
                }
                not_app_restprofile_getcurrent:

                // app_restprofile_get
                if (preg_match('#^/profile/(?P<user>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_restprofile_get')), array (  '_controller' => 'AppBundle\\Controller\\RestProfileController::getAction',));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_restprofile_get;
                    }

                    return $ret;
                }
                not_app_restprofile_get:

                // app_restprofile_addproject
                if (preg_match('#^/profile/(?P<user>[^/]++)/project/(?P<project>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_restprofile_addproject')), array (  '_controller' => 'AppBundle\\Controller\\RestProfileController::addProjectAction',));
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_restprofile_addproject;
                    }

                    return $ret;
                }
                not_app_restprofile_addproject:

                // app_restprofile_removeproject
                if (preg_match('#^/profile/(?P<user>[^/]++)/project/(?P<project>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_restprofile_removeproject')), array (  '_controller' => 'AppBundle\\Controller\\RestProfileController::removeProjectAction',));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_app_restprofile_removeproject;
                    }

                    return $ret;
                }
                not_app_restprofile_removeproject:

                // app_restprofile_put
                if (preg_match('#^/profile/(?P<user>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_restprofile_put')), array (  '_controller' => 'AppBundle\\Controller\\RestProfileController::putAction',));
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_restprofile_put;
                    }

                    return $ret;
                }
                not_app_restprofile_put:

                // app_restprofile_delete
                if (preg_match('#^/profile/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_restprofile_delete')), array (  '_controller' => 'AppBundle\\Controller\\RestProfileController::deleteAction',));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_app_restprofile_delete;
                    }

                    return $ret;
                }
                not_app_restprofile_delete:

                // add_profile_project
                if (preg_match('#^/profile/(?P<user>[^/]++)/project/(?P<project>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'add_profile_project')), array (  '_controller' => 'AppBundle\\Controller\\RestProfileController:addProjectAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_add_profile_project;
                    }

                    return $ret;
                }
                not_add_profile_project:

                // remove_profile_project
                if (preg_match('#^/profile/(?P<user>[^/]++)/project/(?P<project>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'remove_profile_project')), array (  '_controller' => 'AppBundle\\Controller\\RestProfileController:removeProjectAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_remove_profile_project;
                    }

                    return $ret;
                }
                not_remove_profile_project:

                // get_profile_current
                if (preg_match('#^/profile(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'get_profile_current')), array (  '_controller' => 'AppBundle\\Controller\\RestProfileController:getCurrentAction',  '_format' => NULL,));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_get_profile_current;
                    }

                    return $ret;
                }
                not_get_profile_current:

                // get_profile
                if (preg_match('#^/profile/(?P<user>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'get_profile')), array (  '_controller' => 'AppBundle\\Controller\\RestProfileController:getAction',  '_format' => NULL,));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_get_profile;
                    }

                    return $ret;
                }
                not_get_profile:

                // put_profile
                if (preg_match('#^/profile/(?P<user>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'put_profile')), array (  '_controller' => 'AppBundle\\Controller\\RestProfileController:putAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_put_profile;
                    }

                    return $ret;
                }
                not_put_profile:

                // delete_profile
                if (preg_match('#^/profile/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_profile')), array (  '_controller' => 'AppBundle\\Controller\\RestProfileController:deleteAction',  '_format' => NULL,));
                    if (!in_array($requestMethod, array('DELETE'))) {
                        $allow = array_merge($allow, array('DELETE'));
                        goto not_delete_profile;
                    }

                    return $ret;
                }
                not_delete_profile:

            }

            // change_password
            if (0 === strpos($pathinfo, '/password/change') && preg_match('#^/password/change(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'change_password')), array (  '_controller' => 'AppBundle\\Controller\\RestPasswordManagementController:changeAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_change_password;
                }

                return $ret;
            }
            not_change_password:

        }

        elseif (0 === strpos($pathinfo, '/company')) {
            // app_company_get
            if ('/company' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\CompanyController::getAction',  '_route' => 'app_company_get',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_company_get;
                }

                return $ret;
            }
            not_app_company_get:

            // app_company_getactioncompany
            if (preg_match('#^/company/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_company_getactioncompany')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController::getActionCompany',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_company_getactioncompany;
                }

                return $ret;
            }
            not_app_company_getactioncompany:

            // app_company_post
            if ('/company' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\CompanyController::postAction',  '_route' => 'app_company_post',);
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_app_company_post;
                }

                return $ret;
            }
            not_app_company_post:

            // app_company_addcompanyuser
            if (preg_match('#^/company/(?P<id>[^/]++)/user/(?P<id_user>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_company_addcompanyuser')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController::addCompanyUser',));
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_app_company_addcompanyuser;
                }

                return $ret;
            }
            not_app_company_addcompanyuser:

            // app_company_removeuser
            if (preg_match('#^/company/(?P<company>[^/]++)/user/(?P<user>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_company_removeuser')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController::removeUserAction',));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_app_company_removeuser;
                }

                return $ret;
            }
            not_app_company_removeuser:

            // app_company_update
            if (preg_match('#^/company/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_company_update')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController::updateAction',));
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_app_company_update;
                }

                return $ret;
            }
            not_app_company_update:

            // app_company_delete
            if (preg_match('#^/company/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_company_delete')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController::deleteAction',));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_app_company_delete;
                }

                return $ret;
            }
            not_app_company_delete:

            // app_company_postfile
            if (preg_match('#^/company/(?P<company>[^/]++)/file$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_company_postfile')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController::postFileAction',));
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_app_company_postfile;
                }

                return $ret;
            }
            not_app_company_postfile:

            // app_company_deletefile
            if (preg_match('#^/company/(?P<company>[^/]++)/file/(?P<path>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_company_deletefile')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController::deleteFileAction',));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_app_company_deletefile;
                }

                return $ret;
            }
            not_app_company_deletefile:

            // app_company_getfile
            if (preg_match('#^/company/(?P<company>[^/]++)/file/(?P<path>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_company_getfile')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController::getFileAction',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_company_getfile;
                }

                return $ret;
            }
            not_app_company_getfile:

            // remove_company_user
            if (preg_match('#^/company/(?P<company>[^/]++)/user/(?P<user>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'remove_company_user')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController:removeUserAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_remove_company_user;
                }

                return $ret;
            }
            not_remove_company_user:

            // update_company
            if (preg_match('#^/company/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'update_company')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController:updateAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_update_company;
                }

                return $ret;
            }
            not_update_company:

            // get_company
            if (preg_match('#^/company/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'get_company')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController:getActionCompany',  '_format' => NULL,));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_get_company;
                }

                return $ret;
            }
            not_get_company:

            // post_company
            if (preg_match('#^/company(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'post_company')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController:postAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_post_company;
                }

                return $ret;
            }
            not_post_company:

            // delete_company
            if (preg_match('#^/company/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_company')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController:deleteAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_delete_company;
                }

                return $ret;
            }
            not_delete_company:

            // post_company_file
            if (preg_match('#^/company/(?P<company>[^/]++)/file(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'post_company_file')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController:postFileAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_post_company_file;
                }

                return $ret;
            }
            not_post_company_file:

            // delete_company_file
            if (preg_match('#^/company/(?P<company>[^/]++)/file/(?P<path>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_company_file')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController:deleteFileAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_delete_company_file;
                }

                return $ret;
            }
            not_delete_company_file:

            // get_company_file
            if (preg_match('#^/company/(?P<company>[^/]++)/file/(?P<path>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'get_company_file')), array (  '_controller' => 'AppBundle\\Controller\\CompanyController:getFileAction',  '_format' => NULL,));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_get_company_file;
                }

                return $ret;
            }
            not_get_company_file:

        }

        // app_restpasswordmanagement_change
        if ('/change' === $pathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\RestPasswordManagementController::changeAction',  '_route' => 'app_restpasswordmanagement_change',);
            if (!in_array($requestMethod, array('POST'))) {
                $allow = array_merge($allow, array('POST'));
                goto not_app_restpasswordmanagement_change;
            }

            return $ret;
        }
        not_app_restpasswordmanagement_change:

        // homepage
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_homepage;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'homepage'));
            }

            return $ret;
        }
        not_homepage:

        if (0 === strpos($pathinfo, '/mailpreformat')) {
            // app_mailpreformat_get
            if ('/mailpreformat' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\MailPreformatController::getAction',  '_route' => 'app_mailpreformat_get',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_mailpreformat_get;
                }

                return $ret;
            }
            not_app_mailpreformat_get:

            // app_mailpreformat_getactionfortype
            if (preg_match('#^/mailpreformat/(?P<type>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_mailpreformat_getactionfortype')), array (  '_controller' => 'AppBundle\\Controller\\MailPreformatController::getActionForType',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_mailpreformat_getactionfortype;
                }

                return $ret;
            }
            not_app_mailpreformat_getactionfortype:

            // app_mailpreformat_post
            if ('/mailpreformat' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\MailPreformatController::postAction',  '_route' => 'app_mailpreformat_post',);
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_app_mailpreformat_post;
                }

                return $ret;
            }
            not_app_mailpreformat_post:

            // app_mailpreformat_update
            if (preg_match('#^/mailpreformat/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_mailpreformat_update')), array (  '_controller' => 'AppBundle\\Controller\\MailPreformatController::updateAction',));
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_app_mailpreformat_update;
                }

                return $ret;
            }
            not_app_mailpreformat_update:

            // app_mailpreformat_delete
            if (preg_match('#^/mailpreformat/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_mailpreformat_delete')), array (  '_controller' => 'AppBundle\\Controller\\MailPreformatController::deleteAction',));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_app_mailpreformat_delete;
                }

                return $ret;
            }
            not_app_mailpreformat_delete:

            // update_mailpreformat
            if (preg_match('#^/mailpreformat/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'update_mailpreformat')), array (  '_controller' => 'AppBundle\\Controller\\MailPreformatController:updateAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_update_mailpreformat;
                }

                return $ret;
            }
            not_update_mailpreformat:

            // get_mailpreformat
            if (preg_match('#^/mailpreformat/(?P<type>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'get_mailpreformat')), array (  '_controller' => 'AppBundle\\Controller\\MailPreformatController:getActionForType',  '_format' => NULL,));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_get_mailpreformat;
                }

                return $ret;
            }
            not_get_mailpreformat:

            // post_mailpreformat
            if (preg_match('#^/mailpreformat(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'post_mailpreformat')), array (  '_controller' => 'AppBundle\\Controller\\MailPreformatController:postAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_post_mailpreformat;
                }

                return $ret;
            }
            not_post_mailpreformat:

            // delete_mailpreformat
            if (preg_match('#^/mailpreformat/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_mailpreformat')), array (  '_controller' => 'AppBundle\\Controller\\MailPreformatController:deleteAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_delete_mailpreformat;
                }

                return $ret;
            }
            not_delete_mailpreformat:

        }

        elseif (0 === strpos($pathinfo, '/notification')) {
            // app_notification_get
            if ('/notification' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\NotificationController::getAction',  '_route' => 'app_notification_get',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_notification_get;
                }

                return $ret;
            }
            not_app_notification_get:

            // app_notification_put
            if (preg_match('#^/notification/(?P<notification>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_notification_put')), array (  '_controller' => 'AppBundle\\Controller\\NotificationController::putAction',));
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_app_notification_put;
                }

                return $ret;
            }
            not_app_notification_put:

            // app_notification_deleteone
            if (preg_match('#^/notification/(?P<notification>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_notification_deleteone')), array (  '_controller' => 'AppBundle\\Controller\\NotificationController::deleteOneAction',));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_app_notification_deleteone;
                }

                return $ret;
            }
            not_app_notification_deleteone:

            // app_notification_deleteall
            if ('/notification' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\NotificationController::deleteAllAction',  '_route' => 'app_notification_deleteall',);
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_app_notification_deleteall;
                }

                return $ret;
            }
            not_app_notification_deleteall:

        }

        elseif (0 === strpos($pathinfo, '/reminder')) {
            // app_project_forceregenautoreminder
            if ('/reminder/autoregen' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\ProjectController::forceRegenAutoReminder',  '_route' => 'app_project_forceregenautoreminder',);
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_app_project_forceregenautoreminder;
                }

                return $ret;
            }
            not_app_project_forceregenautoreminder:

            // app_reminder_id
            if (preg_match('#^/reminder/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_reminder_id')), array (  '_controller' => 'AppBundle\\Controller\\ReminderController::idAction',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_reminder_id;
                }

                return $ret;
            }
            not_app_reminder_id:

            // app_reminder_get
            if ('/reminder' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\ReminderController::getAction',  '_route' => 'app_reminder_get',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_reminder_get;
                }

                return $ret;
            }
            not_app_reminder_get:

            // app_reminder_post
            if ('/reminder' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\ReminderController::postAction',  '_route' => 'app_reminder_post',);
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_app_reminder_post;
                }

                return $ret;
            }
            not_app_reminder_post:

            // app_reminder_forcevalidation
            if (0 === strpos($pathinfo, '/reminder/forcevalid') && preg_match('#^/reminder/forcevalid/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_reminder_forcevalidation')), array (  '_controller' => 'AppBundle\\Controller\\ReminderController::forceValidation',));
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_app_reminder_forcevalidation;
                }

                return $ret;
            }
            not_app_reminder_forcevalidation:

            // app_reminder_update
            if (preg_match('#^/reminder/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_reminder_update')), array (  '_controller' => 'AppBundle\\Controller\\ReminderController::updateAction',));
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_app_reminder_update;
                }

                return $ret;
            }
            not_app_reminder_update:

            // app_reminder_delete
            if (preg_match('#^/reminder/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_reminder_delete')), array (  '_controller' => 'AppBundle\\Controller\\ReminderController::deleteAction',));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_app_reminder_delete;
                }

                return $ret;
            }
            not_app_reminder_delete:

            // id_reminder
            if (preg_match('#^/reminder/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'id_reminder')), array (  '_controller' => 'AppBundle\\Controller\\ReminderController:idAction',  '_format' => NULL,));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_id_reminder;
                }

                return $ret;
            }
            not_id_reminder:

            // update_reminder
            if (preg_match('#^/reminder/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'update_reminder')), array (  '_controller' => 'AppBundle\\Controller\\ReminderController:updateAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_update_reminder;
                }

                return $ret;
            }
            not_update_reminder:

            // get_reminder
            if (preg_match('#^/reminder(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'get_reminder')), array (  '_controller' => 'AppBundle\\Controller\\ReminderController:getAction',  '_format' => NULL,));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_get_reminder;
                }

                return $ret;
            }
            not_get_reminder:

            // post_reminder
            if (preg_match('#^/reminder(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'post_reminder')), array (  '_controller' => 'AppBundle\\Controller\\ReminderController:postAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_post_reminder;
                }

                return $ret;
            }
            not_post_reminder:

            // delete_reminder
            if (preg_match('#^/reminder/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_reminder')), array (  '_controller' => 'AppBundle\\Controller\\ReminderController:deleteAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_delete_reminder;
                }

                return $ret;
            }
            not_delete_reminder:

        }

        elseif (0 === strpos($pathinfo, '/register')) {
            // app_restregistration_register
            if ('/register' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\RestRegistrationController::registerAction',  '_route' => 'app_restregistration_register',);
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_app_restregistration_register;
                }

                return $ret;
            }
            not_app_restregistration_register:

            // register_registration
            if (preg_match('#^/register(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'register_registration')), array (  '_controller' => 'AppBundle\\Controller\\RestRegistrationController:registerAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_register_registration;
                }

                return $ret;
            }
            not_register_registration:

        }

        // app_restprofile_getallusersraw
        if ('/users' === $pathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\RestProfileController::getAllUsersRaw',  '_route' => 'app_restprofile_getallusersraw',);
            if (!in_array($canonicalMethod, array('GET'))) {
                $allow = array_merge($allow, array('GET'));
                goto not_app_restprofile_getallusersraw;
            }

            return $ret;
        }
        not_app_restprofile_getallusersraw:

        if (0 === strpos($pathinfo, '/server')) {
            // server
            if ('/server' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ServerController::index',  '_route' => 'server',);
            }

            // server_reminder
            if ('/server/reminder' === $pathinfo) {
                return array (  '_controller' => 'AppBundle\\Controller\\ServerReminderController::index',  '_route' => 'server_reminder',);
            }

        }

        elseif (0 === strpos($pathinfo, '/testimonial')) {
            // app_testimonial_get
            if ('/testimonial' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\TestimonialController::getAction',  '_route' => 'app_testimonial_get',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_testimonial_get;
                }

                return $ret;
            }
            not_app_testimonial_get:

            // app_testimonial_post
            if ('/testimonial' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\TestimonialController::postAction',  '_route' => 'app_testimonial_post',);
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_app_testimonial_post;
                }

                return $ret;
            }
            not_app_testimonial_post:

            // app_testimonial_update
            if (preg_match('#^/testimonial/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_testimonial_update')), array (  '_controller' => 'AppBundle\\Controller\\TestimonialController::updateAction',));
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_app_testimonial_update;
                }

                return $ret;
            }
            not_app_testimonial_update:

            // app_testimonial_delete
            if (preg_match('#^/testimonial/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_testimonial_delete')), array (  '_controller' => 'AppBundle\\Controller\\TestimonialController::deleteAction',));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_app_testimonial_delete;
                }

                return $ret;
            }
            not_app_testimonial_delete:

            // update_project
            if (preg_match('#^/testimonial/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'update_project')), array (  '_controller' => 'AppBundle\\Controller\\TestimonialController:updateAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_update_project;
                }

                return $ret;
            }
            not_update_project:

            // get_project
            if (preg_match('#^/testimonial(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'get_project')), array (  '_controller' => 'AppBundle\\Controller\\TestimonialController:getAction',  '_format' => NULL,));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_get_project;
                }

                return $ret;
            }
            not_get_project:

            // post_project
            if (preg_match('#^/testimonial(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'post_project')), array (  '_controller' => 'AppBundle\\Controller\\TestimonialController:postAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_post_project;
                }

                return $ret;
            }
            not_post_project:

            // delete_project
            if (preg_match('#^/testimonial/(?P<id>[^/\\.]++)(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_project')), array (  '_controller' => 'AppBundle\\Controller\\TestimonialController:deleteAction',  '_format' => NULL,));
                if (!in_array($requestMethod, array('DELETE'))) {
                    $allow = array_merge($allow, array('DELETE'));
                    goto not_delete_project;
                }

                return $ret;
            }
            not_delete_project:

        }

        // post_login
        if (0 === strpos($pathinfo, '/login') && preg_match('#^/login(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
            $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'post_login')), array (  '_controller' => 'AppBundle\\Controller\\RestLoginController:postAction',  '_format' => NULL,));
            if (!in_array($requestMethod, array('POST'))) {
                $allow = array_merge($allow, array('POST'));
                goto not_post_login;
            }

            return $ret;
        }
        not_post_login:

        if ('/' === $pathinfo && !$allow) {
            throw new Symfony\Component\Routing\Exception\NoConfigurationException();
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
