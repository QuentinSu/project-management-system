<?php

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $valueHoldere4a1b = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer50846 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties7bd28 = [
        
    ];

    public function getConnection()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getConnection', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getMetadataFactory', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getExpressionBuilder', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'beginTransaction', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getCache', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getCache();
    }

    public function transactional($func)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'transactional', array('func' => $func), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->transactional($func);
    }

    public function commit()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'commit', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->commit();
    }

    public function rollback()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'rollback', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getClassMetadata', array('className' => $className), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'createQuery', array('dql' => $dql), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'createNamedQuery', array('name' => $name), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'createQueryBuilder', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'flush', array('entity' => $entity), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->flush($entity);
    }

    public function find($entityName, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'find', array('entityName' => $entityName, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->find($entityName, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'clear', array('entityName' => $entityName), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->clear($entityName);
    }

    public function close()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'close', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->close();
    }

    public function persist($entity)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'persist', array('entity' => $entity), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'remove', array('entity' => $entity), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'refresh', array('entity' => $entity), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'detach', array('entity' => $entity), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'merge', array('entity' => $entity), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getRepository', array('entityName' => $entityName), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'contains', array('entity' => $entity), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getEventManager', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getConfiguration', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'isOpen', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getUnitOfWork', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getProxyFactory', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'initializeObject', array('obj' => $obj), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'getFilters', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'isFiltersStateClean', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'hasFilters', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return $this->valueHoldere4a1b->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? $reflection = new \ReflectionClass(__CLASS__);
        $instance = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer50846 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHoldere4a1b) {
            $reflection = $reflection ?: new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHoldere4a1b = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHoldere4a1b->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, '__get', ['name' => $name], $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        if (isset(self::$publicProperties7bd28[$name])) {
            return $this->valueHoldere4a1b->$name;
        }

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldere4a1b;

            $backtrace = debug_backtrace(false);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    get_parent_class($this),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
            return;
        }

        $targetObject = $this->valueHoldere4a1b;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldere4a1b;

            return $targetObject->$name = $value;
            return;
        }

        $targetObject = $this->valueHoldere4a1b;
        $accessor = function & () use ($targetObject, $name, $value) {
            return $targetObject->$name = $value;
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, '__isset', array('name' => $name), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldere4a1b;

            return isset($targetObject->$name);
            return;
        }

        $targetObject = $this->valueHoldere4a1b;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, '__unset', array('name' => $name), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHoldere4a1b;

            unset($targetObject->$name);
            return;
        }

        $targetObject = $this->valueHoldere4a1b;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __clone()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, '__clone', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        $this->valueHoldere4a1b = clone $this->valueHoldere4a1b;
    }

    public function __sleep()
    {
        $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, '__sleep', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;

        return array('valueHoldere4a1b');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null)
    {
        $this->initializer50846 = $initializer;
    }

    public function getProxyInitializer()
    {
        return $this->initializer50846;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer50846 && ($this->initializer50846->__invoke($valueHoldere4a1b, $this, 'initializeProxy', array(), $this->initializer50846) || 1) && $this->valueHoldere4a1b = $valueHoldere4a1b;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHoldere4a1b;
    }

    public function getWrappedValueHolderValue() : ?object
    {
        return $this->valueHoldere4a1b;
    }


}
